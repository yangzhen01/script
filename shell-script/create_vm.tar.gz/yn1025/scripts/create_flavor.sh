#!/bin/sh

cd `dirname $0`
source ../admin-openrc.sh

nova aggregate-create typev2p-aggr
nova aggregate-set-metadata typev2p-aggr hw=typev2p

for i in {1..9};do nova aggregate-create type$i-aggr; nova aggregate-set-metadata type$i-aggr hw=type$i;done

nova flavor-create type1 auto 131072 1024 40
nova flavor-key type1 set hw:cpu_sockets=2 hw:cpu_cores=10 hw:cpu_threads=2
nova flavor-key type1 set hw:numa_nodes=2
nova flavor-key type1 set hw:numa_cpus.0=0-9,20-29 hw:numa_mem.0=65536
nova flavor-key type1 set hw:numa_cpus.1=10-19,30-39 hw:numa_mem.1=65536
nova flavor-key type1 set guest:smbios_mode=host
nova flavor-key type1 set guest:balloon_autodeflate=on guest:reserve_memory=0
nova flavor-key type1 set local_disk:disk_num=12
nova flavor-key type1 set local_disk:disk_type.0=bare_scsi local_disk:disk_capacity_gb.0=3600 local_disk:disk_share.0=1
nova flavor-key type1 set local_disk:disk_type.1=bare_scsi local_disk:disk_capacity_gb.1=3600 local_disk:disk_share.1=1
nova flavor-key type1 set local_disk:disk_type.2=bare_scsi local_disk:disk_capacity_gb.2=3600 local_disk:disk_share.2=1
nova flavor-key type1 set local_disk:disk_type.3=bare_scsi local_disk:disk_capacity_gb.3=3600 local_disk:disk_share.3=1
nova flavor-key type1 set local_disk:disk_type.4=bare_scsi local_disk:disk_capacity_gb.4=3600 local_disk:disk_share.4=1
nova flavor-key type1 set local_disk:disk_type.5=bare_scsi local_disk:disk_capacity_gb.5=3600 local_disk:disk_share.5=1
nova flavor-key type1 set local_disk:disk_type.6=bare_scsi local_disk:disk_capacity_gb.6=3600 local_disk:disk_share.6=1
nova flavor-key type1 set local_disk:disk_type.7=bare_scsi local_disk:disk_capacity_gb.7=3600 local_disk:disk_share.7=1
nova flavor-key type1 set local_disk:disk_type.8=bare_scsi local_disk:disk_capacity_gb.8=3600 local_disk:disk_share.8=1
nova flavor-key type1 set local_disk:disk_type.9=bare_scsi local_disk:disk_capacity_gb.9=3600 local_disk:disk_share.9=1
nova flavor-key type1 set local_disk:disk_type.10=bare_scsi local_disk:disk_capacity_gb.10=3600 local_disk:disk_share.10=1
nova flavor-key type1 set local_disk:disk_type.11=bare_scsi local_disk:disk_capacity_gb.11=3600 local_disk:disk_share.11=1

nova flavor-create type2 auto 131072 1024 40
nova flavor-key type2 set hw:cpu_sockets=2 hw:cpu_cores=10 hw:cpu_threads=2
nova flavor-key type2 set hw:numa_nodes=2
nova flavor-key type2 set hw:numa_cpus.0=0-9,20-29 hw:numa_mem.0=65536
nova flavor-key type2 set hw:numa_cpus.1=10-19,30-39 hw:numa_mem.1=65536
nova flavor-key type2 set guest:smbios_mode=host
nova flavor-key type2 set guest:balloon_autodeflate=on guest:reserve_memory=0
nova flavor-key type2 set local_disk:disk_num=1
nova flavor-key type2 set local_disk:disk_type.0=bare_scsi local_disk:disk_capacity_gb.0=2100 local_disk:disk_share.0=1

nova flavor-create type3 auto 262144 1024 40
nova flavor-key type3 set hw:cpu_sockets=2 hw:cpu_cores=10 hw:cpu_threads=2
nova flavor-key type3 set hw:numa_nodes=2
nova flavor-key type3 set hw:numa_cpus.0=0-9,20-29 hw:numa_mem.0=131072
nova flavor-key type3 set hw:numa_cpus.1=10-19,30-39 hw:numa_mem.1=131072
nova flavor-key type3 set guest:smbios_mode=host
nova flavor-key type3 set guest:balloon_autodeflate=on guest:reserve_memory=0
nova flavor-key type3 set local_disk:disk_num=1
nova flavor-key type3 set local_disk:disk_type.0=bare_scsi local_disk:disk_capacity_gb.0=3200 local_disk:disk_share.0=1

nova flavor-create type4 auto 262144 1024 40
nova flavor-key type4 set hw:cpu_sockets=2 hw:cpu_cores=10 hw:cpu_threads=2
nova flavor-key type4 set hw:numa_nodes=2
nova flavor-key type4 set hw:numa_cpus.0=0-9,20-29 hw:numa_mem.0=131072
nova flavor-key type4 set hw:numa_cpus.1=10-19,30-39 hw:numa_mem.1=131072
nova flavor-key type4 set guest:smbios_mode=host
nova flavor-key type4 set guest:balloon_autodeflate=on guest:reserve_memory=0
nova flavor-key type4 set local_disk:disk_num=3
nova flavor-key type4 set local_disk:disk_type.0=bare_scsi local_disk:disk_capacity_gb.0=3200 local_disk:disk_share.0=1
nova flavor-key type4 set local_disk:disk_type.1=bare_nvme local_disk:disk_capacity_gb.1=2900 local_disk:disk_bus.1=fakenvme local_disk:disk_share.1=1
nova flavor-key type4 set local_disk:disk_type.2=bare_nvme local_disk:disk_capacity_gb.2=2900 local_disk:disk_bus.2=fakenvme local_disk:disk_share.2=1

nova flavor-create type5 auto 524288 1024 40
nova flavor-key type5 set hw:cpu_sockets=2 hw:cpu_cores=10 hw:cpu_threads=2
nova flavor-key type5 set hw:numa_nodes=2
nova flavor-key type5 set hw:numa_cpus.0=0-9,20-29 hw:numa_mem.0=262144
nova flavor-key type5 set hw:numa_cpus.1=10-19,30-39 hw:numa_mem.1=262144
nova flavor-key type5 set guest:smbios_mode=host
nova flavor-key type5 set guest:balloon_autodeflate=on guest:reserve_memory=0
nova flavor-key type5 set local_disk:disk_num=1
nova flavor-key type5 set local_disk:disk_type.0=bare_scsi local_disk:disk_capacity_gb.0=3200 local_disk:disk_share.0=1

nova flavor-create type6 auto 524288 1024 40
nova flavor-key type6 set hw:cpu_sockets=2 hw:cpu_cores=10 hw:cpu_threads=2
nova flavor-key type6 set hw:numa_nodes=2
nova flavor-key type6 set hw:numa_cpus.0=0-9,20-29 hw:numa_mem.0=262144
nova flavor-key type6 set hw:numa_cpus.1=10-19,30-39 hw:numa_mem.1=262144
nova flavor-key type6 set guest:smbios_mode=host
nova flavor-key type6 set guest:balloon_autodeflate=on guest:reserve_memory=0
nova flavor-key type6 set local_disk:disk_num=2
nova flavor-key type6 set local_disk:disk_type.0=bare_scsi local_disk:disk_capacity_gb.0=2100 local_disk:disk_share.0=1
nova flavor-key type6 set local_disk:disk_type.1=bare_nvme local_disk:disk_capacity_gb.1=2900 local_disk:disk_bus.1=fakenvme local_disk:disk_share.1=1

nova flavor-create type7 auto 524288 1024 112
nova flavor-key type7 set hw:cpu_sockets=4 hw:cpu_cores=14 hw:cpu_threads=2
nova flavor-key type7 set hw:numa_nodes=4
nova flavor-key type7 set hw:numa_cpus.0=0-13,56-69 hw:numa_mem.0=131072
nova flavor-key type7 set hw:numa_cpus.1=14-27,70-83 hw:numa_mem.1=131072
nova flavor-key type7 set hw:numa_cpus.2=28-41,84-97 hw:numa_mem.2=131072
nova flavor-key type7 set hw:numa_cpus.3=42-55,98-111 hw:numa_mem.3=131072
nova flavor-key type7 set guest:smbios_mode=host
nova flavor-key type7 set guest:balloon_autodeflate=on guest:reserve_memory=0
nova flavor-key type7 set local_disk:disk_num=1
nova flavor-key type7 set local_disk:disk_type.0=bare_scsi local_disk:disk_capacity_gb.0=9800 local_disk:disk_share.0=1

nova flavor-create type8 auto 524288 1024 112
nova flavor-key type8 set hw:cpu_sockets=4 hw:cpu_cores=14 hw:cpu_threads=2
nova flavor-key type8 set hw:numa_nodes=4
nova flavor-key type8 set hw:numa_cpus.0=0-13,56-69 hw:numa_mem.0=131072
nova flavor-key type8 set hw:numa_cpus.1=14-27,70-83 hw:numa_mem.1=131072
nova flavor-key type8 set hw:numa_cpus.2=28-41,84-97 hw:numa_mem.2=131072
nova flavor-key type8 set hw:numa_cpus.3=42-55,98-111 hw:numa_mem.3=131072
nova flavor-key type8 set guest:smbios_mode=host
nova flavor-key type8 set guest:balloon_autodeflate=on guest:reserve_memory=0
nova flavor-key type8 set local_disk:disk_num=1
nova flavor-key type8 set local_disk:disk_type.0=bare_scsi local_disk:disk_capacity_gb.0=2100 local_disk:disk_share.0=1

nova flavor-create type9 auto 524288 1024 112
nova flavor-key type9 set hw:cpu_sockets=4 hw:cpu_cores=14 hw:cpu_threads=2
nova flavor-key type9 set hw:numa_nodes=4
nova flavor-key type9 set hw:numa_cpus.0=0-13,56-69 hw:numa_mem.0=131072
nova flavor-key type9 set hw:numa_cpus.1=14-27,70-83 hw:numa_mem.1=131072
nova flavor-key type9 set hw:numa_cpus.2=28-41,84-97 hw:numa_mem.2=131072
nova flavor-key type9 set hw:numa_cpus.3=42-55,98-111 hw:numa_mem.3=131072
nova flavor-key type9 set guest:smbios_mode=host
nova flavor-key type9 set guest:balloon_autodeflate=on guest:reserve_memory=0
nova flavor-key type9 set local_disk:disk_num=2
nova flavor-key type9 set local_disk:disk_type.0=bare_scsi local_disk:disk_capacity_gb.0=2100 local_disk:disk_share.0=1
nova flavor-key type9 set local_disk:disk_type.1=bare_nvme local_disk:disk_capacity_gb.1=2900 local_disk:disk_bus.1=fakenvme local_disk:disk_share.1=1


nova flavor-create typev2p auto 262144 1024 40
nova flavor-key typev2p set hw:cpu_sockets=2 hw:cpu_cores=10 hw:cpu_threads=2
nova flavor-key typev2p set hw:numa_nodes=2
nova flavor-key typev2p set hw:numa_cpus.0=0-9,20-29 hw:numa_mem.0=131072
nova flavor-key typev2p set hw:numa_cpus.1=10-19,30-39 hw:numa_mem.1=131072
nova flavor-key typev2p set guest:smbios_mode=host
nova flavor-key typev2p set guest:balloon_autodeflate=on guest:reserve_memory=0
nova flavor-key typev2p set local_disk:disk_num=1
nova flavor-key typev2p set local_disk:disk_type.0=bare_scsi local_disk:disk_capacity_gb.0=2100 local_disk:disk_share.0=1


for i in {1..9};do nova flavor-key type$i set hw=type$i;done
nova flavor-key typev2p set hw=typev2p

