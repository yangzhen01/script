#!/bin/sh

cd `dirname $0`
source ../cfg/base.cfg
source ./openrc

check_servers(){
    nova list
    local KEY=$KEY_NAME".pem"

    >~/.ssh/known_hosts
    for fip in `cat ../cfg/floatingip.cfg |grep -vE '^#|^$'|awk '{print $3}'`
    do
        echo $fip"START================================================================"
        ssh -i $KEY root@$fip -o StrictHostKeyChecking=no hostname
        ssh -i $KEY root@$fip ip a
        ssh -i $KEY root@$fip curl http://169.254.169.254/
        ssh -i $KEY root@$fip ping -c 1 www.baidu.com -i 0.1
        echo $fip"END=================================================================="
        echo
        echo
        echo
    done
}

check_servers
