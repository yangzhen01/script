#!/bin/bash
hostname=$(hostname -s)
zabbix_server=172.28.23.248 

uuid=$(dmidecode -s system-uuid|tr 'A-Z' 'a-z')
hostmetadata=virtual_server_group_1
sed -i "s/^ServerActive=127.0.0.1/ServerActive=$zabbix_server/" /etc/zabbix/zabbix_agentd.conf
sed -i "s/^Server=127.0.0.1/Server=$zabbix_server/"  /etc/zabbix/zabbix_agentd.conf
sed -i "s/^Hostname=Zabbix server/Hostname=$hostname--$uuid/" /etc/zabbix/zabbix_agentd.conf
sed -i "s/^HostMetadata=virtual_server/HostMetadata=$hostmetadata/" /etc/zabbix/zabbix_agentd.conf
systemctl restart zabbix-agent
