#!/bin/sh

# 限制虚拟机网卡速率为1000Mb

NET_ID=$1
QOS=aaaaaaaa-aaaa-aaaa-aaaa-000000001000

for id in `openstack port list --device-owner compute:nova  --long --network $NET_ID -f value |awk '{print $1}'`
do
    openstack port set --qos-policy $QOS $id
done
