#!/bin/sh

cd `dirname $0`
source ./openrc
source ../cfg/base.cfg
source ./common.sh

create_key(){
    nova keypair-add $KEY_NAME > $KEY_NAME'.pem'
    chmod 600 $KEY_NAME'.pem'
}

create_servers(){
    local instance_name=$1
    local instance_ip=$2
    local flavor=$3
    local image_id=$4
    local vda_size=$5
    local volume_type=$6
    local hypervisor_host=$7
    local az=$8
    local net_id=$9
    #local ephemeral=${10}
    local tag=${10}

if [ "$hypervisor_host" = "null"  ];then
    #echo "
    #openstack server create --flavor $flavor --nic net-id=$net_id,v4-fixed-ip=$instance_ip --image $image_id  --property admin_pass=$SERVER_PASS --property nic_multiqueue_enabled=True --availability-zone $az $instance_name
    nova boot --flavor $flavor --nic net-id=$net_id,v4-fixed-ip=$instance_ip --image $image_id --meta admin_pass=$SERVER_PASS --meta nic_multiqueue_enabled=true --availability-zone $az --tags $tag $instance_name &
    #"
else
    #openstack server create --flavor $flavor --nic net-id=$net_id,v4-fixed-ip=$instance_ip --image $image_id  --property admin_pass=$SERVER_PASS --property nic_multiqueue_enabled=True --availability-zone $az::$hypervisor_host $instance_name &
    nova boot --flavor $flavor --nic net-id=$net_id,v4-fixed-ip=$instance_ip --image $image_id --meta admin_pass=$SERVER_PASS --meta nic_multiqueue_enabled=true --availability-zone $az:$hypervisor_host --tags $tag $instance_name &
fi
}

create_vm(){
    local PROJECT=$OS_PROJECT_NAME
    local USER=$OS_USERNAME

    #KEY_FLAG=`nova keypair-list|grep $KEY_NAME`
    #if [ "$KEY_FLAG" == "" ];then
    #    create_key
    #fi

    source ../admin-openrc.sh
    openstack role add --project $PROJECT --user $USER admin
    logout "$?" "openstack role add --project $PROJECT --user $USER admin"

    source ./openrc
    cat ../cfg/server.cfg|grep -vE '^#|^$' >tmp

    read_cfg_and_operate create_servers tmp

    source ../admin-openrc.sh
    echo "openstack role remove --project $PROJECT --user $USER admin"
    logout "$?" "openstack role remove --project $PROJECT --user $USER admin"
}

create_vm
