#!/bin/sh

cd `dirname $0`
source ../admin-openrc.sh
source ./common.sh

if [ "$1" == "" ];then
    echo "Please enter project name."
    echo "./$0 <Project name>"
    exit 1
fi

#项目名
PROJECT=$1
#用户名
USER=$1
#密码
PASSWORD=$1
#角色
ROLE=${2:-'user'}

create_project(){
    #创建项目
    openstack project create $PROJECT
    logout "$?" "openstack project create $PROJECT"
    #创建用户
    openstack user create --project $PROJECT --password $PASSWORD $USER
    logout "$?" "openstack user create $USER"
    #分配角色
    openstack role add --project $PROJECT --user $USER $ROLE
    logout "$?" "openstack role add $ROLE"

    >openrc
    #创建openrc文件
    echo "export OS_PROJECT_DOMAIN_NAME=default" >> openrc
    echo "export OS_USER_DOMAIN_NAME=default" >> openrc
    echo "export OS_PROJECT_NAME=$PROJECT" >> openrc
    echo "export OS_USERNAME=$USER" >> openrc
    echo "export OS_PASSWORD=$PASSWORD" >> openrc
    echo "export OS_AUTH_URL=$OS_AUTH_URL" >> openrc
    echo "export OS_IDENTITY_API_VERSION=3" >> openrc
    echo "export OS_IMAGE_API_VERSION=2" >> openrc
}

create_project
