#!/bin/sh

cd `dirname $0`
source ./common.sh
source ../admin-openrc.sh

add_aggregate(){
    local host=$1
    local aggregate=$2
    nova aggregate-add-host $aggregate $host &
}

cat ../cfg/compute.cfg|grep -vE '^#|^$' >tmp

read_cfg_and_operate add_aggregate tmp

