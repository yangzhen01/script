#!/bin/sh

cd `dirname $0`
source ../cfg/base.cfg
source ../admin-openrc.sh
source ../scripts/common.sh

cinder type-create $VOLUME_TYPE
logout "$?" "cinder type-create $VOLUME_TYPE"
