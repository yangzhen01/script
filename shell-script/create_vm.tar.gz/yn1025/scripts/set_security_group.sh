#!/bin/sh

cd `dirname $0`
source ./openrc
source ./common.sh

set_security_group_rule(){
    local protocol=$1
    local port=$2
    local cidr=$3
    local security_group=$4

    if [ "$protocol" = "icmp" ];then
        openstack security group rule create --protocol $protocol --remote-ip $cidr --ingress $security_group
        logout "$?" "security group rule create $protocol"
    elif [ "$protocol" = "tcp" -o "$protocol" = "udp" ];then
        openstack security group rule create --protocol $protocol --remote-ip $cidr --ingress --dst-port $port $security_group
        logout "$?" "security group rule create $protocol"
    else
        openstack security group rule create --protocol icmp --remote-ip $cidr --ingress $security_group
        openstack security group rule create --protocol tcp --remote-ip $cidr --ingress $security_group
        openstack security group rule create --protocol udp --remote-ip $cidr --ingress $security_group
        logout "$?" "security group rule create $protocol"
    fi
}

cat ../cfg/security_group.cfg|grep -vE '^#|^$' >tmp
read_cfg_and_operate set_security_group_rule tmp
