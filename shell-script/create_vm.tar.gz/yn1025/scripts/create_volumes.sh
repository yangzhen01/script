#!/bin/sh

cd `dirname $0`
source ./openrc
source ./common.sh

usage(){
    echo "./$0 create_blank_volume"
    echo "./$0 create_volume_from_image"
    echo "./$0 create_volume_from_volume"
    echo "./$0 create_volume_from_backup"
}

wait_for_status(){
    local volume_name=$1
    status=`openstack volume list|grep bjh|awk '{print $6}'`
    if [ "$status" == "available"  ];then
        exit 0
    elif [ "$status" == "error" ];then
        exit 1
    else
        sleep 5
    fi
}

create_blank_volume(){
    local volume_name=$1
    local volume_size=$2
    local volume_type=$3
    local source_image_id=$4
    local source_volume_id=$5
    local source_backup_id=$6
    local server_name=$7

    openstack volume create  --size $volume_size --type $volume_type $volume_name
    logout "$?" "openstack volume create $volume_name"
    
    openstack server add volume $server_name $volume_name
    logout "$?" "openstack server add volume $volume_name"
}

create_volume_from_image(){
    local volume_name=$1
    local volume_size=$2
    local volume_type=$3
    local source_image_id=$4
    local source_volume_id=$5
    local source_backup_id=$6
    local server_name=$7

    openstack volume create --size $volume_size --type $volume_type --image $source_image_id $volume_name
    logout "$?" "openstack volume create $volume_name"
    openstack server add volume $server_name $volume_name
    logout "$?" "openstack server add volume $volume_name"
}

create_volume_from_volume(){
    local volume_name=$1
    local volume_size=$2
    local volume_type=$3
    local source_image_id=$4
    local source_volume_id=$5
    local source_backup_id=$6
    local server_name=$7

    openstack volume create --size $volume_size --type $volume_type --source $source_volume_id $volume_name
    logout "$?" "openstack volume create $volume_name"
    openstack server add volume $server_name $volume_name
    logout "$?" "openstack server add volume $volume_name"
}

create_volume_from_backup(){
    local volume_name=$1
    local volume_size=$2
    local volume_type=$3
    local source_image_id=$4
    local source_volume_id=$5
    local source_backup_id=$6
    local server_name=$7

    cinder backup-restore --name $volume_name $source_backup_id
    logout "$?" "openstack volume create $volume_name"
    openstack server add volume $server_name $volume_name
    logout "$?" "openstack server add volume $volume_name"
}

cat ../cfg/volume.cfg|grep -vE '^#|^$' >tmp

case $1 in
create_blank_volume)
    read_cfg_and_operate create_blank_volume tmp
    ;;
create_volume_from_image)
    read_cfg_and_operate create_volume_from_image tmp
    ;;
create_volume_from_volume)
    read_cfg_and_operate create_volume_from_volume tmp
    ;;
create_volume_from_backup)
    read_cfg_and_operate create_volume_from_backup tmp
    ;;
*)
    usage
    ;;
esac
