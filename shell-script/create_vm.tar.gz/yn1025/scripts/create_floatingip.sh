#!/bin/sh

cd `dirname $0`
source ./openrc
source ../cfg/base.cfg
source ./common.sh

create_floatingip(){
    local server_name=$1
    local fixed_ip=$2
    local floatingip=$3
    #local limit=$4
    local qos=$4

    #neutron floatingip-create --floating-ip-address $floatingip --rate-limit $limit $FLOATING_NETWORK
    #logout "$?" "neutron floatingip-create $floatingip"
    openstack floating ip create --floating-ip-address $floatingip --qos-policy $qos $FLOATING_NETWORK 
    logout "$?" "openstack floating ip create $floatingip"

    openstack server add floating ip --fixed-ip-address $fixed_ip $server_name $floatingip
    logout "$?" "openstack  server add floating ip $floatingip"
}

add_floatingip(){
    local PROJECT=$OS_PROJECT_NAME
    local USER=$OS_USERNAME

    source ../admin-openrc.sh
    openstack role add --project $PROJECT --user $USER admin
    logout "$?" "openstack role add --project $PROJECT --user $USER admin"

    source ./openrc
    cat ../cfg/floatingip.cfg|grep -vE '^#|^$' >tmp
    read_cfg_and_operate create_floatingip tmp

    openstack role remove --project $PROJECT --user $USER admin
    logout "$?" "openstack role remove --project $PROJECT --user $USER admin"
}

add_floatingip
