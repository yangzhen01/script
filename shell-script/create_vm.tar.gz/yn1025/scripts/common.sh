#!/bin/sh

source /etc/init.d/functions

read_cfg_and_operate(){
    local func_name=$1
    local tmp_file=$2

    while read line
    do
        $func_name $line
    done< $tmp_file
}

logout(){
    if [ $1 = 0 ] ;then
        action "$2 " /bin/true
    else
        action "$2 " /bin/false
        exit 1
    fi
}

log_no_out(){
    if [ $1 = 0 ] ;then
        action "$2 " /bin/true
    else
        action "$2 " /bin/false
    fi
}

change_color(){
    COLOR=$2
    if [ "$COLOR" == "" ];then
        COLOR="36m"
    fi
    echo -e "\033["$COLOR""$1"\033[m"
}
