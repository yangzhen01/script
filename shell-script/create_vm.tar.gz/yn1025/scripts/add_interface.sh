#!/bin/sh

cd `dirname $0`
source ./openrc
source ./common.sh

cat ../cfg/interface.cfg|grep -vE '^#|^$' >tmp

add_interface(){
    local server_name=$1
    local network_name=$2
    local ip=$3

    #openstack server add fixed ip --fixed-ip-address $ip $server_name $network_name
    # 无IP
    openstack server add fixed ip $server_name $network_name &
}

read_cfg_and_operate add_interface tmp
