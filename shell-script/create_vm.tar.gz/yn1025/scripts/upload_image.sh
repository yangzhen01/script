#!/bin/sh

cd `dirname $0`
source ../admin-openrc.sh

curl -o qemu-centos74-gansu-boot.qcow2 http://36.111.0.80:40000/gansu/qemu-centos74-gansu-boot.qcow2
glance image-create --name "CentOS74-boot-`date +%F`" --file ./qemu-centos74-gansu-boot.qcow2 --disk-format qcow2 --container-format bare --visibility public --protected True --property hw_qemu_guest_agent=yes --property os_type="linux" --property os_distro="centos" --property os_version="7.4" --property hw_vif_multiqueue_enabled=true --property zabbix_enabled=true --property hw_scsi_model=virtio-scsi --property hw_disk_bus=scsi  --progress
