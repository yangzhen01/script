#!/bin/sh

cd `dirname $0`
source ../scripts/common.sh
source ./openrc

TMP_PATH=./delete
usage(){
    echo `change_color "#help: 1.source openrc file;  2.choose to delete this project resource." 33m`
    echo "./$0 delete_servers    "`change_color "#help:delete all servers" 33m`
    echo "./$0 delete_volumes    "`change_color "#help:delete all volumes" 33m`
    echo "./$0 delete_backups    "`change_color "#help:delete all volume backups" 33m`
    echo "./$0 delete_networks   "`change_color "#help:delete all routers,networks,subnets" 33m`
    echo "./$0 delete_keys       "`change_color "#help:delete all keypairs" 33m`
    echo "./$0 delete_secgroups  "`change_color "#help:delete all security groups except default" 33m`
    echo "./$0 delete_fips       "`change_color "#help:delete all floating ips" 33m`
    echo "./$0 delete_images     "`change_color "#help:delete all private images" 33m`
    echo "./$0 delete_project    "`change_color "#help:delete this project and user" 33m`
    echo "./$0 delete_all        "`change_color "#help:delete this project's all resource and itself" 33m`
}
delete_servers(){
    echo "Delete servers start......"
    >$TMP_PATH/vm_ids
    #获取所有的虚拟机ID
    nova list|awk '{print $2}'|sed '/^$/d'|sed '1d'>$TMP_PATH/vm_ids
    for vm_id in `cat $TMP_PATH/vm_ids`
    do
        nova delete $vm_id
        logout "$?" "nova delete $vm_id"
    done
    echo
}

delete_volumes(){
    echo "Delete volumes start......"
    >$TMP_PATH/volume_ids
    #获取所有的卷ID
    cinder list|awk '{print $2}'|sed '/^$/d'|sed '1d'>$TMP_PATH/volume_ids
    for volume_id in `cat $TMP_PATH/volume_ids`
    do
        cinder delete $volume_id
        logout "$?" "cinder delete $volume_id"
    done
    echo
}

delete_backups(){
    echo "Delete backups start......"
    >$TMP_PATH/backup_ids
    #获取所有备份ID
    cinder backup-list --sort created_at:desc|awk '{print $2}'|sed '/^$/d'|sed '1d'>$TMP_PATH/backup_ids
    for backup_id in `cat $TMP_PATH/backup_ids`
    do
        cinder backup-delete $backup_id
        logout "$?" "cinder backup-delete $backup_id"
    done
    echo
}

delete_networks(){
    echo "Delete networks start......"
    >$TMP_PATH/router_ids
    >$TMP_PATH/subnet_ids
    >$TMP_PATH/net_ids
    #获取路由ID
    openstack router list -f value -c ID>$TMP_PATH/router_ids
    for router_id in `cat $TMP_PATH/router_ids`
    do
        #获取所有绑定的子网ID
        openstack  port list --router $router_id -f value|awk -F "'" '{print $4}'|sort|uniq>$TMP_PATH/subnet_ids
        for subnet_id in `cat $TMP_PATH/subnet_ids`
        do
            openstack router remove subnet $router_id $subnet_id
            logout "$?" "openstack router remove subnet $router_id $subnet_id"
        done
        #删除路由
        openstack router delete $router_id
        logout "$?" "openstack router delete $router_id"
    done

    #获取所有的内网的ID
    openstack  network list --no-share -f value -c ID>$TMP_PATH/net_ids
    for net_id in `cat $TMP_PATH/net_ids`
    do
        openstack network delete $net_id
        log_no_out "$?" "openstack network delete $net_id"
    done
    echo
}

delete_keys(){
    echo "Delete keys start......"
    >$TMP_PATH/keys
    #获取key名称
    nova keypair-list|awk '{print $2}'|sed '/^$/d'|sed '1d'>$TMP_PATH/keys
    for key in `cat $TMP_PATH/keys`
    do
       nova keypair-delete $key
       logout "$?" "nova keypair-delete $key"
    done
    echo
}

delete_secgroups(){
    echo "Delete security groups start......"
    >$TMP_PATH/sec_ids
    #获取安全组的ID
    openstack security group list -f value -c ID>$TMP_PATH/sec_ids
    for sec_id in `cat $TMP_PATH/sec_ids`
    do
        openstack security group delete $sec_id
        log_no_out "$?" "openstack security group delete $sec_id"
    done
    echo
}

delete_fips(){
    echo "Delete floating ips start......"
    >$TMP_PATH/fip_ids
    #获取浮动ip的ID
    openstack floating ip list -f value -c ID>$TMP_PATH/fip_ids
    for fip_id in `cat $TMP_PATH/fip_ids`
    do
        openstack floating ip delete $fip_id
        logout "$?" "openstack floating ip delete $fip_id"
    done
    echo
}

delete_images(){
    echo "Delete images start......"
    >$TMP_PATH/image_ids
    #获取私有镜像ID
    glance image-list --visibility private|awk '{print $2}'|sed '/^$/d'|sed '1d'>$TMP_PATH/image_ids
    for image_id in `cat $TMP_PATH/image_ids`
    do
        glance image-delete $image_id
        logout "$?" "glance image-delete $image_id"
    done
    echo
}

delete_project(){
    echo "Delete project and user start......"
    PROJECT=$OS_PROJECT_NAME
    USER=$OS_USERNAME
    source ../admin-openrc.sh
    #获取user的ID
    USERID=`openstack user list|grep -w $USER|awk '{print $2}'`
    openstack user delete $USERID
    logout "$?" "openstack user delete $USERID"
    #获取project的ID
    PROJECTID=`openstack project list|grep -w $PROJECT|awk '{print $2}'`
    openstack project delete $PROJECTID
    logout "$?" "openstack project delete $PROJECTID"
    echo
}

case $1 in
delete_servers)
    delete_servers
    ;;
delete_volumes)
    delete_volumes
    ;;
delete_backups)
    delete_backups
    ;;
delete_networks)
    delete_networks
    ;;
delete_keys)
    delete_keys
    ;;
delete_secgroups)
    delete_secgroups
    ;;
delete_fips)
    delete_fips
    ;;
delete_images)
    delete_images
    ;;
delete_project)
    delete_project
    ;;
delete_all)
    delete_servers
    delete_volumes
    delete_backups
    delete_networks
    delete_keys
    delete_secgroups
    delete_fips
    delete_images
    delete_project
    ;;
*)
    usage
    ;;
esac
