#!/bin/sh

cd `dirname $0`
source ./openrc
source ../cfg/base.cfg
source ./common.sh

ROUTE_NAME=${1:-$OS_PROJECT_NAME'_router'}

create_router(){
    router_flag=`openstack router list |grep -w $ROUTE_NAME|wc -l`
    if [ $router_flag -eq 0 ];then
        #创建路由
        openstack router create $ROUTE_NAME
    fi
    openstack router set --external-gateway $FLOATING_NETWORK $ROUTE_NAME
    logout "$?" "openstack router set"
}

create_network(){
    local NET_NAME=$1
    local SUBNET_NAME=$2
    local CIDR=$3
    local GATEWAY=$4
    local IF_ROUTER=$5
    local NETWORK_TYPE=vlan
    local VLAN_ID=$6

    NET_ID=`openstack network list|grep -w $NET_NAME|awk '{print $2}'`
    if [ "$NET_ID" = "" ];then
        #创建网络
        # NET_ID=`openstack network create $NET_NAME|grep -w id|awk '{print $4}'`
        # 关闭安全组
        # NET_ID=`openstack network create --disable-port-security $NET_NAME|grep -w id|awk '{print $4}'`
        # 设置vlan
        NET_ID=`openstack network create --disable-port-security --provider-network-type $NETWORK_TYPE --provider-physical-network external --provider-segment $VLAN_ID $NET_NAME|grep -w id|awk '{print $4}'`
    fi

    subnet_flag=`openstack subnet list|grep $NET_ID|grep $SUBNET_NAME|wc -l`
    if [ $subnet_flag -eq 0 ];then
        #openstack subnet create --dns-nameserver $DNS --dhcp --ip-version 4 --network $NET_ID --subnet-range $CIDR --gateway $GATEWAY $SUBNET_NAME
        openstack subnet create  --dhcp --ip-version 4 --network $NET_ID --subnet-range $CIDR --gateway $GATEWAY $SUBNET_NAME
        # 无dhcp
        #openstack subnet create  --no-dhcp --ip-version 4 --network $NET_ID --subnet-range $CIDR --gateway $GATEWAY $SUBNET_NAME
    fi

    if [ "$IF_ROUTER" = "Y" ];then
        #将子网添加到路由
        openstack router add subnet $ROUTE_NAME $SUBNET_NAME
        #echo
    fi
}

# create_router

create(){
    local PROJECT=$OS_PROJECT_NAME
    local USER=$OS_USERNAME

    source ../admin-openrc.sh
    openstack role add --project $PROJECT --user $USER admin
    logout "$?" "openstack role add --project $PROJECT --user $USER admin"

    source ./openrc
    cat ../cfg/network.cfg|grep -vE '^#|^$' >tmp
    read_cfg_and_operate create_network tmp

    source ../admin-openrc.sh
    openstack role remove --project $PROJECT --user $USER admin
    logout "$?" "openstack role remove --project $PROJECT --user $USER admin"
}

create
