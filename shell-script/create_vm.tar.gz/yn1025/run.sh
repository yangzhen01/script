#!/bin/sh
source ./cfg/base.cfg
source ./scripts/common.sh

usage(){
    echo "./$0 create_admin_openrc          #help:Create admin openrc file."
    echo "./$0 create_flavor                #help:Create flavors."
    echo "./$0 add_aggregate                #help:Add compute node to aggregate."
    echo "./$0 create_volume_type           #help:Create a volume type."
    echo "./$0 create_project               #help:Create a project."
    echo "./$0 create_network               #help:Create networks in a project."
    echo "./$0 set_security_group           #help:Set security group rules."
    echo "./$0 create_servers               #help:Create servers."
    echo "./$0 disable_port                 #help:Disable network port"
    echo "./$0 attach_volume                #help:Attach volumes to servers."
    echo "./$0 add_interface                #help:Add interfaces to servers."
    echo "./$0 add_floatingip               #help:Add floatingip to server."
    echo "./$0 set_port_qos <network_id>    [#help: Set port qos.]"
    echo "./$0 check_server                 #help:Check if can ssh servers."
    echo "./$0 delete_resource              #help:Delete resource in a project."
    echo "./$0 all                          #help:Run all."
}

create_admin_openrc(){
    >admin-openrc.sh
    echo "export OS_PROJECT_DOMAIN_NAME=default" >> admin-openrc.sh
    echo "export OS_USER_DOMAIN_NAME=default" >> admin-openrc.sh
    echo "export OS_PROJECT_NAME=$ADMIN_PROJECT_NAME" >> admin-openrc.sh
    echo "export OS_USERNAME=$ADMIN_USERNAME" >> admin-openrc.sh
    echo "export OS_PASSWORD=$ADMIN_PASSWORD" >> admin-openrc.sh
    echo "export OS_AUTH_URL=$AUTH_URL" >> admin-openrc.sh
    echo "export OS_IDENTITY_API_VERSION=3" >> admin-openrc.sh
    echo "export OS_IMAGE_API_VERSION=2" >> admin-openrc.sh
}

create_flavor(){
    sh ./scripts/create_flavor.sh
}

create_volume_type(){
    sh ./scripts/create_type.sh
}

create_project(){
    sh ./scripts/create_project.sh $PROJECT_NAME
    cp ./scripts/openrc .
}

create_network(){
    sh ./scripts/create_network.sh
    source ./openrc
    for net in `cat ./cfg/network.cfg|grep -vE '^#|^$'|awk '{print $1}'|uniq`
    do
        net_id=`openstack network list|grep -w $net|awk '{print $2}'`
        sed -i 's#'$net'#'$net_id'#g' ./cfg/server.cfg
    done
}

set_security_group(){
    sh ./scripts/set_security_group.sh
}

create_servers(){
    sh ./scripts/create_servers.sh
}

attach_volume(){
    cat ./cfg/volume.cfg|grep -vE '^#|^$' >tmp
    while read v_name v_size v_type image_id volume_id backup_id vm
    do
        if [ "$image_id" = "null" -a "$volume_id" = "null" -a "$backup_id" = "null" ];then
            sh ./scripts/create_volumes.sh create_blank_volume
            exit 0
        elif [ "$image_id" != "null" ];then
            sh ./scripts/create_volumes.sh create_volume_from_image
            exit 0
        elif [ "$volume_id" != "null" ];then
            sh ./scripts/create_volumes.sh create_volume_from_volume
            exit 0
        elif [ "$backup_id" != "null" ];then
            sh ./scripts/create_volumes.sh create_volume_from_backup
            exit 0
        else
            echo "volume.cfg format may be error."
            exit 1
        fi
    done<tmp
}

add_interface(){
    sh ./scripts/add_interface.sh
}

add_floatingip(){
    sh ./scripts/create_floatingip.sh
}

check_server(){
    sh ./scripts/check_servers.sh
}

delete_resource(){
    sh ./scripts/delete_resource.sh delete_all
}

set_port_qos(){
    sh ./scripts/set_port_qos.sh $1 
    openstack port list --device-owner compute:nova  --long --network $1 -f value |awk '{print $1}' |while read line;do openstack port show $line -f value -c qos_policy_id;done
}

disable_port(){
    for id in `openstack port list --network $1 --device-owner compute:public -f value -c ID`
    do
        openstack port set --disable $id
    done
    openstack port list --network $1 --device-owner compute:public
}

add_aggregate(){
    sh ./scripts/add_aggregate.sh
}

case $1 in
create_admin_openrc)
    create_admin_openrc
    logout "$?" "create_admin_openrc"
    ;;
create_flavor)
    create_flavor
    logout "$?" "create_flavor"
    ;;
create_volume_type)
    create_volume_type
    logout "$?" "create_volume_type"
    ;;
create_project)
    create_project
    logout "$?" "create_project"
    ;;
create_network)
    create_network
    logout "$?" "create_network"
    ;;
set_security_group)
    set_security_group
    logout "$?" "set_security_group"
    ;;
create_servers)
    create_servers
    logout "$?" "create_servers"
    ;;
attach_volume)
    attach_volume
    logout "$?" "attach_volume"
    ;;
add_interface)
    add_interface
    logout "$?" "add_interface"
    ;;
add_floatingip)
    add_floatingip
    logout "$?" "add_floatingip"
    ;;
check_server)
    check_server
    logout "$?" "check_server"
    ;;
delete_resource)
    delete_resource
    logout "$?" "delete_resource"
    ;;
set_port_qos)
    set_port_qos $2
    logout "$?" "set_port_qos $2"
    ;;
disable_port)
    disable_port $2
    logout "$?" "disable_port $2"
    ;;
add_aggregate)
    add_aggregate
    logout "$?" "add_aggregate"
    ;;
all)
    create_admin_openrc
    logout "$?" "create_admin_openrc"
    create_flavor
    logout "$?" "create_flavor"
    create_volume_type
    logout "$?" "create_volume_type"
    create_project
    logout "$?" "create_project"
    create_network
    logout "$?" "create_network"
    set_security_group
    logout "$?" "set_security_group"
    create_servers
    logout "$?" "create_servers"
    attach_volume
    logout "$?" "attach_volume"
    add_interface
    logout "$?" "add_interface"
    add_floatingip
    logout "$?" "add_floatingip"
    check_server
    logout "$?" "check_server"
    ;;
*)
    usage
    ;;
esac
