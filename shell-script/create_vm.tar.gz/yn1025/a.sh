#!/bin/sh

source ./openrc

TAG=third_delivery

#for id in `nova list --tags $TAG |grep ACTIVE|awk '{print $2}'`
for id in `nova list|awk '{print $2}'`
do
    # nova lock $id &
    #nova server-tag-add $id second_delivery &
    #nova delete $id &
done

