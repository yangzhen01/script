#!/bin/sh
source ./admin-openrc.sh

SEVER_ID=$1
if [ "$SEVER_ID" == "" ];then
    echo "Please enter a server ID"
    echo "./$0 <server_id>"
    exit 1
fi

HOST=`nova show $SEVER_ID|grep -w host|awk '{print $4}'`
PROJECT_ID=`nova show $SEVER_ID|grep tenant_id|awk '{print $4}'`
echo "host:"$HOST
echo "project ID:"$PROJECT_ID
openstack project show $PROJECT_ID|grep -E 'description|name'|awk '{print "project "$2":"$4}'

