#!/bin/sh

source ../openrc

NETWORK_ID=$1

#IP_PRE=`openstack port list --device-owner network:dhcp  --network $NETWORK_ID |grep ip_address|head -1|awk -F "'" '{print $2}'|sed -n 's#\(.*\)\..*#\1#gp'`
IP_PRE=135.32.113
echo $IP_PRE

num=251
for id in `openstack port list --device-owner network:dhcp  --network $NETWORK_ID -f value -c ID`
do
    echo $num
    openstack port set  --no-fixed-ip --fixed-ip ip-address=$IP_PRE.$num $id
    num=$((num+1))
done

openstack port list --device-owner network:dhcp  --network $NETWORK_ID
