#!/bin/bash

source ./config.cfg
source ./demo-openrc.sh

create_image() {
    echo "Which type of image you want to create:"
    select type in "KVM" "Ironic" "Cancel";
    do
    case $type in
    KVM )
        openstack image create ${KVM_IMAGE} --file ${KVM_IMAGE_FILE} --disk-format raw --container-format bare --property img_hv_type=qemu --property hw_qemu_guest_agent=yes --property os_type="linux"  --property hw_vif_multiqueue_enabled=true --property img_hv_type=qemu
        break
        ;;
    Ironic )
        openstack image create ${IRONIC_IMAGE} --file ${IRONIC_IMAGE_FILE} --disk-format qcow2 --container-format bare --public --tag store:swift --property img_hv_type=baremetal
        break
        ;;
    Cancel )
        break
        ;;
    esac
    done
}

#create_flavor() {
#    openstack flavor create --vcpus ${VCPUS} --ram ${RAM} ${FLAVOR}
#}

#create_flavor
create_image
