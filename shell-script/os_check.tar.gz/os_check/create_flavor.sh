#! /bin/bash
source ./config.cfg
source ./admin-openrc.sh


create_flavor(){
   flavor_flag=$(openstack flavor list|grep -w $FLAVOR |wc -l)
   if [[ $flavor_flag -ne 0 ]];then
    echo "the flavor is already existed"
    exit
   fi
   openstack flavor create --vcpus $VCPUS  --ram $RAM $FLAVOR

}


create_flavor
