#!/bin/bash

source ./logout.sh
source ./admin-openrc.sh
check_status() {
case $1 in
nova)
    process_status=$($1 service-list  | awk -F '|' '{print  $3 $4 $6 $7}' | grep -E "down|disabled" | awk '{print $2": "$1}')
    if [[ $process_status = "" ]]; then
        log_no_out "0" "nova service"
    else
        echo $process_status
        log_no_out "1" "nova service"
    fi
;;
neutron)
    process_status=$($1 agent-list | awk -F '|' '{print $4 $6 $8 }' | grep xxx | awk '{print $1 ": "$3 }')
    if [[ $process_status = "" ]]; then
        log_no_out "0" "neutron service"
    else
        echo $process_status
        log_no_out "1" "neutron service"
    fi
;;
cinder)
    process_status=`$1 service-list | awk -F '|' '{print $2 $3 $5 $6}' | grep -E "down|disabled" | awk '{print $2": "$1}'`
    if [[ $process_status = "" ]]; then
        log_no_out "0" "cinder service"
    else
        echo $process_status
        log_no_out "1" "cinder service"
    fi
;;
hypervisor)
   num=$(openstack hypervisor list | grep down | wc -l )
   if [[ $num=0 ]]; then
      log_no_out "0" "hypervisor service"
   else
      log_no_out "1" "hypervisor service"
   fi
;;
esac
}

check_status nova
check_status neutron
check_status cinder
check_status hypervisor
