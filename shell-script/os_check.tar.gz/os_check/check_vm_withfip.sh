#!/bin/bash

source ./config.cfg
#source ./demo-openrc.sh
source ./admin-openrc.sh
bind_fip() {
    count=`nova list |grep ACTIVE|grep $INSTANCE_NAME|wc -l`
    active_count=`openstack  floating ip list|grep $FLOATINGIP_PRE|grep None|wc -l`
    need_count=$(($count - $active_count))
    #申请浮动IP
    for i in `seq $need_count`
    do
        #neutron floatingip-create --rate-limit $RATE_LIMIT $FLOATING_NETWORK
         openstack floating ip create $FLOATING_NETWORK
    done
    #将申请的浮动ip写入到fips
    openstack  floating ip list|grep $FLOATINGIP_PRE|grep  None|awk '{print $4}'|head -$count>fips

    #将所有实例的id,写入到vm_ids
    nova list |grep ACTIVE |grep $INSTANCE_NAME|awk '{print $2}'|head -$count>vm_ids

    paste vm_ids fips>vm_fips

    while read vm_id fip
    do
       # nova floating-ip-associate $vm_id $fip
        openstack server add floating ip $vm_id $fip
    done<vm_fips

    #添加安全组规则，保证ping和ssh
    #neutron security-group-rule-create --direction ingress  --protocol icmp default
    #neutron security-group-rule-create --direction ingress  --protocol tcp --port-range-min 22 --port-range-max 22 default
}

#check_vm() {
#    create_servers
#    KEY=$KEY".pem"
#
#    #输出绑定成功的列表
#    echo "The server list is:"
#    echo "==================================================================="
#    nova list|grep $INSTANCE_NAME|grep $FLOATINGIP_PRE
#    echo "==================================================================="
#
#    sleep 3
#    >~/.ssh/known_hosts
#    FIP_FILE=fips
#    for fip in `cat $FIP_FILE`
#    do
#        echo $fip"START================================================================"
#        ssh -i $KEY root@$fip -o StrictHostKeyChecking=no hostname
#        ssh -i $KEY root@$fip ip a
#        ssh -i $KEY root@$fip curl http://169.254.169.254/
#        ssh -i $KEY root@$fip ping -c 3 www.baidu.com
#        echo $fip"END=================================================================="
#        echo
#        echo
#        echo
#    done
#}

bind_fip
#time check_vm|tee check_vm.log



