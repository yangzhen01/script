#! /bin/bash
source ./admin-openrc.sh
source ./config.cfg

show_vncurl(){
  uuid=$(nova list --all |grep $INSTANCE_NAME | awk '{print$2}')
  openstack console url show $uuid

}

show_vncurl
