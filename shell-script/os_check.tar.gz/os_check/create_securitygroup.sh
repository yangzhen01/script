#! /bin/bash

source ./config.cfg
source ./admin-openrc.sh

create_securitygroup(){
 security_flag=`openstack security group list | grep $SECURITYGROUP | wc -l `
 if [[ $security_flag -ne 0 ]] ;then
 echo "the name already existed"
   exit
 fi  
 openstack security group create $SECURITYGROUP
 openstack security group rule create --proto icmp $SECURITYGROUP
 openstack security group rule create --proto tcp --dst-port 22 $SECURITYGROUP
}
create_securitygroup
