#!/bin/bash

source ./admin-openrc.sh
source ./config.cfg
source ./logout.sh
#source ./demo-openrc.sh

source ./create_project.sh
source ./check_service_status.sh
source ./create_pub_net.sh
source ./create_flavor.sh
source ./down_create_images.sh
#source ./demo-openrc.sh
#source ./create_images.sh
source ./create_tenant_net.sh
source ./create_securitygroup.sh
source ./create_servers.sh
source ./check_vm_withfip.sh
