#!/bin/bash
source ./admin-openrc.sh
#source ./demo-openrc.sh
source ./config.cfg

create_tenant_net() {
    net_flag=`neutron net-list|grep -w $NET|wc -l`
    if [ $net_flag -eq 0 ];then
        #创建网络
        neutron net-create $NET
    fi

    #获取NET_ID
    NET_ID=`neutron net-list|grep -w $NET|awk '{print $2}'`

    subnet_flag=`neutron net-list -c subnets --name $NET|grep /|wc -l`
    if [ $subnet_flag -eq 0 ];then
        neutron subnet-create --name $SUBNET --dns-nameserver $DNS_SERVER --enable-dhcp --ip-version 4 $NET_ID $CIDR
    fi

    SUBNET_ID=`neutron net-list -c subnets --name $NET|grep / |head -1|awk '{print $2}'`

    router_flag=`neutron router-list |grep -w $ROUTE|wc -l`
    if [ $router_flag -eq 0 ];then
        #创建路由
        neutron router-create $ROUTE
    fi
    neutron router-gateway-set $ROUTE $FLOATING_NETWORK
    ROUTE_ID=`neutron router-list|grep -w $ROUTE|awk '{print $2}'`

    #将子网添加到路由
    neutron router-interface-add $ROUTE_ID subnet=$SUBNET_ID
}

create_tenant_net
