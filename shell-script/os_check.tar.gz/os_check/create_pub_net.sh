#!/bin/bash

source ./config.cfg
source ./admin-openrc.sh

create_subnet() {
   echo "Which type of subnet you want:"
   select sub in "Normal" "Transpond" "Cancel";
   do
       case $sub in
       Normal )
           openstack subnet create --gateway ${PUB_GW} --allocation-pool start=${DHCP_START},end=${DHCP_END} --network ${PUB_NET} --subnet-range ${PUB_CIDR} ${PUB_SUB}
           break
           ;;
       Transpond )
           openstack subnet create ${FIP_AGENT_SUB} --subnet-range ${FIP_AGENT_SUB_CIDR} --no-dhcp --service-type 'network:floatingip_agent_gateway' --service-type 'network:router_gateway'  --network ext-net --allocation-pool start=${FIP_DHCP_START},end=${FIP_DHCP_END} --gateway ${FIP_AGENT_SUB_GW}
           openstack subnet create ${PUB_SUB}  --subnet-range ${PUB_CIDR} --no-dhcp  --service-type 'network:floatingip' --network ext-net --allocation-pool start=${DHCP_START},end=${DHCP_END} --gateway ${PUB_GW}
           break
           ;;
       Cancel )
           break
           ;;
       esac
   done
}

create_pubnet() {
    echo "Which type of public network you want:"
    select net in "Vlan" "Flat" "Cancel";
    do
    case $net in
    Vlan )
        openstack network create --external --provider-network-type vlan --provider-physical-network external --provider-segment ${VLAN_ID} ${PUB_NET}
        create_subnet
        break
        ;;
    Flat)
        openstack network create --external --provider-network-type flat --provider-physical-network external ${PUB_NET}
        openstack subnet create --network ${PUB_NET} --allocation-pool start=${DHCP_START},end=${DHCP_END} --dns-nameserver ${DNS} --gateway ${PUB_GW} --subnet-range ${PUB_CIDR} ${PUB_SUB}
        break
        ;;
    Cancel)
        break
        ;;
    esac
    done
}

create_pubnet
