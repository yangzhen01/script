# 验收脚本说明
## 文件描述
| File name               | Description                                  |
|:----------------------- |:---------------------------------------------|
| check_service_status.sh | 检查 compute/volume/network agent 等服务状态 |
| create_pub_net.sh       | 创建公网                                     |
| create_tenant_net.sh    | 创建租户网、创建路由并设置网关与接口         |
| create_servers.sh       | 创建虚拟机并检查虚机状态                     |
| check_vm_withfip.sh     | 创建 floating ip 并绑定虚机，检查网络连通性  |
| admin_openrc.sh         | admin用户访问 OpenStack 的 credentials       |
| check_all.sh            | 串联以上所有文件任务                         |

## 使用方法
> 在使用之前，需仔细阅读并填写 config.cfg 文件
可按照上述文件功能，根据实际需求来进行单个或多个功能进行验收，一般验收步骤如下：
1. 创建公网
2. 创建租户网
3. 创建路由并设置网关与接口
4. 创建虚拟机(可批量创建)
5. 验证虚拟机状态
6. 创建 floating ip 并与虚机绑定
7. 检查虚拟机的网络连通性
