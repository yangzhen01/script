#!/bin/sh
source /etc/init.d/functions

function logout()
{
    if [ $1 = 0 ] ;then
        action "$2" /bin/true
    else
        action "$2" /bin/false
        exit 1
    fi
}

function log_no_out()
{
    if [ $1 = 0 ] ;then
        action "$2" /bin/true
    else
        action "$2" /bin/false
    fi
}
