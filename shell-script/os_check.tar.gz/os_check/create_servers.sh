#!/bin/bash
source ./config.cfg
#source ./demo-openrc.sh
source ./admin-openrc.sh
#set -x

#批量创建虚拟机
create_servers() {
#    KEY=$OS_USERNAME
#    #创建key
#    KEY_FLAG=`nova keypair-list|grep $KEY`
#    if [ "$KEY_FLAG" == "" ];then
#        nova keypair-add $KEY > $KEY'.pem'
#        chmod 600 $KEY'.pem'
#    fi

    NET_ID=`openstack network list | grep $NET | awk '{print $2}'`
    #IMAGE_ID=`glance image-list|grep ${KVM_IMAGE} | head -1 | awk '{print $2}'`
    #INSTANCE_NAME=`uuidgen | head -c 6`
    #创建实例
   nova boot --flavor ${FLAVOR}  --image ${KVM_IMAGE} --nic net-id=${NET_ID} --min-count ${INSTANCE_MIN_COUNT}  --security-group $SECURITYGROUP --meta admin_pass=$VMPASSWORD $INSTANCE_NAME
}

create_servers
