#! /bin/bash

curl -O http://36.111.0.80:40000/shanghai_public/190224/qemu-centos68-public.qcow2
curl -O http://36.111.0.80:40000/shanghai_public/190224/qemu-centos75-public.qcow2
curl -O http://36.111.0.80:40000/shanghai_public/190224/qemu-ubuntu1604-public.qcow2


for i in `ls|grep qcow2|awk -F '.' '{print $1}'`;do qemu-img convert -f qcow2 -O raw $i.qcow2 $i.raw;done

cp ./*.raw /data/images

#Centos 6.8
glance image-create --name "CentOS6.8" --file /data/images/qemu-centos68-public.raw --disk-format raw --container-format bare --visibility public --protected True --property hw_qemu_guest_agent=yes --property os_type="linux" --property os_distro="centos" --property os_version="6.8" --property hw_vif_multiqueue_enabled=true --property ctcm_enabled=true --progress 

#Centos7.5
glance image-create --name "CentOS7.5" --file /data/images/qemu-centos75-public.raw --disk-format raw --container-format bare --visibility public --protected True --property hw_qemu_guest_agent=yes --property os_type="linux" --property os_distro="centos" --property os_version="7.5" --property hw_vif_multiqueue_enabled=true --property ctcm_enabled=true --progress

#Ubuntu16
glance image-create --name "Ubuntu16.04" --file /data/images/qemu-ubuntu1604-public.raw --disk-format raw --container-format bare --visibility public --protected True --property hw_qemu_guest_agent=yes --property os_type="linux" --property os_distro="ubuntu" --property os_version="16.04" --property hw_vif_multiqueue_enabled=true --property ctcm_enabled=true --progress


