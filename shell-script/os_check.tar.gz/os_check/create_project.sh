#!/bin/sh

source ../admin-openrc.sh
source ./logout.sh
source ./config.cfg

AUTH_URL=`cat ../admin-openrc.sh | grep AUTH_URL | awk -F'=' '{print $2}' | awk -F'10006' '{print $1}'`

create_project(){
    #创建项目
    openstack project create $PROJECT
    logout "$?" "openstack project create $PROJECT"
    #创建用户
    openstack user create --project $PROJECT --password $PASSWORD $USER
    logout "$?" "openstack user create $USER"
    #分配角色
    openstack role add --project $PROJECT --user $USER $ROLE
    logout "$?" "openstack role add $ROLE"

    #touch demo-openrc.sh
    ##创建openrc文件
    #echo "export OS_PROJECT_DOMAIN_NAME=default" >> demo-openrc.sh
    #echo "export OS_USER_DOMAIN_NAME=default" >> demo-openrc.sh
    #echo "export OS_PROJECT_NAME=$PROJECT" >> demo-openrc.sh
    #echo "export OS_USERNAME=$USER" >> demo-openrc.sh
    #echo "export OS_PASSWORD=$PASSWORD" >> demo-openrc.sh
#   # echo "export OS_AUTH_URL=${AUTH_URL}10008/v3" >> demo-openrc.sh
    #echo "export OS_AUTH_URL=${AUTH_URL}10006/v3" >> demo-openrc.sh
    #echo "export OS_IDENTITY_API_VERSION=3" >> demo-openrc.sh
    #echo "export OS_IMAGE_API_VERSION=2" >> demo-openrc.sh
}

create_project
