#!/bin/bash

source ../demo-openrc.sh
source ../config.cfg

delete_vms() {
    if [[ `openstack server list | wc -l` == 0 ]]
        pass
    else
        for id in `openstack server list | grep ACTIVE | awk -F'|' '{print $2}'`
        do
            openstack server delete ${id}
        done
    fi
}

delete_fips() {
    if [[ `openstack floatingip list | wc -l` == 0 ]]
        pass
    else
        for fip in `openstack floating ip list | awk -F'|' '{print $2}' | grep -vE '^ ID|^$'`
        do
            openstack floating ip unset $fip
            openstack floating ip delete $fip
        done
    fi
}

delete_fips
delete_vms
