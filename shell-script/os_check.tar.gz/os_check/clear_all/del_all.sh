#! /bin/bash
source ./admin-openrc.sh
source ./config.cfg

openstack server delete $INSTANCE_NAME
openstack flavor delete $FLAVOR
openstack security group delete $SECURITYGROUP
openstack image  delete $KVM_IMAGE
openstack router remove subnet $ROUTE $SUBNET
openstack subnet delete $SUBNET
openstack network delete $NET
openstack router delete $ROUTE
fip=$(openstack floating ip list | grep -w None|awk '{print$4}')
openstack floating ip delete $fip
openstack user delete $USER
openstack project delete $PROJECT



