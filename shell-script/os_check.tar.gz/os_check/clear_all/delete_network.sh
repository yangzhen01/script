#!/bin/bash

source ../config.cfg
source ../demo-openrc.sh


delete_ports() {
    
}
