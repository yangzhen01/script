#!/bin/bash
source /etc/init.d/functions

function logout()
{
    if [ $1 = 0 ] ;then
        action "$2" /bin/true
    else
        action "$2" /bin/false
        exit 1
    fi
}
