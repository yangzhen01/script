#!/bin/bash
./set_hosts.sh
./install_docker_compose.sh
./harbor.sh
#
#当以上正确执行后，再执行下面这条命令
#./auto_pull_image.sh
