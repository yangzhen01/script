#!/bin/bash
source ./config
source ./result.sh

ret=$(echo -e "$docker $docker_name\n$local_ip $local_name" >>/etc/hosts)
ret_code=$?
logout $ret_code "配置 /etc/hosts"
