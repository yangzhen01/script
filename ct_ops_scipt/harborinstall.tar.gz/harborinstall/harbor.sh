#!/bin/bash

source ./config
source ./result.sh

#安装 harbor
install_harbor(){
  #wget https://storage.googleapis.com/harbor-releases/release-1.8.0/harbor-offline-installer-v1.8.1.tgz
  ret_code=$?
  logout $ret_code "Harbor 下载！"
}

config_harbor(){
  tar zxvf harbor-offline-installer-v1.8.1.tgz
  cd harbor && sed -i -e "s/reg.mydomain.com/$local_name/g" -e "s/port: 80/port: 60001/g" -e "s/Harbor12345/ctyun123456/g" -e "s/data_volume: \/data/data_volume: \/data\/harbor/g" harbor.yml
  ./install.sh
  ret_code=$?
  logout $ret_code "Harbor 配置及启动！"
}

edit_docker_compose(){
  cd harbor
  sed -i "/tag: \"core\"/a\    extra_hosts:\n      - "$docker_name:$docker"\n      - "$local_name:$local_ip"" docker-compose.yml
  sed -i "/tag: \"jobservice\"/a\    extra_hosts:\n      - "$docker_name:$docker"\n      - "$local_name:$local_ip"" docker-compose.yml
  docker-compose up -d
}

install_harbor
config_harbor
edit_docker_compose
