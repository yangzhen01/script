#!/bin/bash

source ./config

echo "创建${cloud_name}远程仓库"
 
curl -X POST \
  http://$1:60001/api/registries \
  -H 'authorization: Basic YWRtaW46Y3R5dW4xMjM0NTY=' \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -H 'postman-token: b103a0d1-c731-f253-b4e7-7e11ce436629' \
  -d "{
  "id":1,
  "url": "docker.ctyun.cn:60001",
  "name": "${cloud_name}harbor",
  "credential": {
    "type": "basic",
    "access_key": "admin",
    "access_secret": "xYgMtKDBJn6BEnRxTAVQqtZU"
  },
  "type": "harbor",
  "insecure": false,
  "description": ""
}"
 
 
echo "创建拉取moho仓库任务..."
 
curl -X POST \
  http://$1:60001/api/replication/policies \
  -H 'authorization: Basic YWRtaW46Y3R5dW4xMjM0NTY=' \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -H 'postman-token: a081bf78-6a3a-3dd3-cd1c-50edc1520519' \
  -d "
  {
    "id":1,
        "name": "${cloud_name_en}-moho-pull",
        "description": "",
        "creator": "admin",
        "src_registry": {
          "id":1,
            "name": "${cloud_name}公有云",
            "description": "",
            "type": "harbor",
            "url": "http://docker.ctyun.cn:60001",
            "token_service_url": "",
            "credential": {
                "type": "basic",
                "access_key": "admin",
                "access_secret": "xYgMtKDBJn6BEnRxTAVQqtZU"
            },
            "insecure": false
        },
        "filters": [
            {
                "type": "name",
                "value": "moho/*"
            }
        ],
        "trigger": {
            "type": "scheduled",
            "trigger_settings": {
                "cron": "0 0 0/1 * * ? "
            }
        },
        "deletion": false,
        "override": true,
        "enabled": true
    }
"
 
echo "手动拉取一次..."
 
curl -X POST \
  http://$1:60001/api/replication/executions \
  -H 'authorization: Basic YWRtaW46Y3R5dW4xMjM0NTY=' \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -H 'postman-token: 93a2aef3-38cf-6592-71aa-1a2b0c6324f0' \
  -d "{
  "id": 0,
  "policy_id": 1
}"
 
echo "拉取任务状态"
 
curl -X GET \
  http://$1:60001/api/replication/executions \
  -H 'authorization: Basic YWRtaW46Y3R5dW4xMjM0NTY=' \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -H 'postman-token: 5200b2a9-088f-e6c9-6aaf-56b22e913c86' \
  -d '{
  "id": 0,
  "policy_id": 1
}'
 
echo "创建拉取library仓库任务..."
 
curl -X POST \
  http://$1:60001/api/replication/policies \
  -H 'authorization: Basic YWRtaW46Y3R5dW4xMjM0NTY=' \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -H 'postman-token: a081bf78-6a3a-3dd3-cd1c-50edc1520519' \
  -d "
  {
    "id":2,
        "name": "${cloud_name_en}-library-pull",
        "description": "",
        "creator": "admin",
        "src_registry": {
          "id":1,
            "name": "${cloud_name}公有云",
            "description": "",
            "type": "harbor",
            "url": "http://docker.ctyun.cn:60001",
            "token_service_url": "",
            "credential": {
                "type": "basic",
                "access_key": "admin",
                "access_secret": "xYgMtKDBJn6BEnRxTAVQqtZU"
            },
            "insecure": false
        },
        "filters": [
            {
                "type": "name",
                "value": "library/*"
            }
        ],
        "trigger": {
            "type": "scheduled",
            "trigger_settings": {
                "cron": "0 0 0/1 * * ? "
            }
        },
        "deletion": false,
        "override": true,
        "enabled": true
    }
"
 
 
echo "手动拉取一次..."
 
curl -X POST \
  http://$1:60001/api/replication/executions \
  -H 'authorization: Basic YWRtaW46Y3R5dW4xMjM0NTY=' \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -H 'postman-token: 93a2aef3-38cf-6592-71aa-1a2b0c6324f0' \
  -d '{
  "id": 1,
  "policy_id": 2
}'
 
echo "拉取任务状态"
 
curl -X GET \
  http://$1:60001/api/replication/executions \
  -H 'authorization: Basic YWRtaW46Y3R5dW4xMjM0NTY=' \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -H 'postman-token: 5200b2a9-088f-e6c9-6aaf-56b22e913c86' \
  -d '{
  "id": 1,
  "policy_id": 2
}'
 
echo "初始化完成。。。"
