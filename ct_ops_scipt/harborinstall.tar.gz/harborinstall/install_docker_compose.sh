#!/bin/bash

source ./result.sh

#下载 docker-compose 并设置权限
install_docker_compose(){
  #curl -L https://github.com/docker/compose/releases/download/1.24.1/docker-compose-`uname -s`-`uname -m` > /usr/bin/docker-compose && \
  chmod +x /usr/bin/docker-compose
  /usr/bin/docker-compose -v
  sleep 3
  ret_code=$?
  logout $ret_code "docker-compose 下载及权限设置！"
}

#下载 docker 并启动
install_docker(){
  #curl -O https://download.docker.com/linux/centos/docker-ce.repo && yum makecache fast
  yum -y install docker-ce-19.03.1*
  cat > /etc/docker/daemon.json << EOF
{"registry-mirrors": ["http://f1361db2.m.daocloud.io"],
 "insecure-registries" : [
    "docker.ctyun.cn:60001"
  ]
}
EOF
  systemctl daemon-reload
  systemctl restart docker
  ret_code=$?
  logout $ret_code "docker 下载并启动！"
}

install_docker_compose
install_docker
